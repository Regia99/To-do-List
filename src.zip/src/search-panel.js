import React from "react";

const SearchPanel = () => {
  return <input type="text" placeholder="Type to search" />;
};

export default SearchPanel;

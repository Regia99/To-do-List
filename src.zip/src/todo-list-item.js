import React, { Component } from "react";

const TodoListItem = ({ important, label }) => {
  const style = {
    color: important ? "steelblue" : "black",
    fontWeight: important ? "bold" : "normal",
  };

  console.log(important);

  return (
    <span style={style} >
      {label}{" "}
    </span>
  );
};

export default TodoListItem;

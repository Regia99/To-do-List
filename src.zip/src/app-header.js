import React from "react";

const AppHeader = () => {
  return <h1>Todo List App</h1>;
};

export default AppHeader;

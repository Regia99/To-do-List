import React from "react";
import TodoListItem from "./todo-list-item";

const TodoList = ({ todos }) => {
  const elements = todos.map((item) => {
    const { id, ...elProps } = item;

    return (
      <li key={id}>
        <TodoListItem {...elProps} />
      </li>
    );
  });

  return <ul>{elements}</ul>;
};

export default TodoList;
